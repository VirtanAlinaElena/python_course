import urllib.request
def name_generator():
  import random
  prenume = ["Jonas","Lora","Michael","Jessica"]
  nume = ["Hammer","Drill","Cutter","Knife"]
  randomNumber1 = random.randrange(0,len(prenume))
  randomNumber2 = random.randrange(0,len(nume))
  name = prenume[randomNumber1] + " " + nume[randomNumber2]
  print(name)

name_generator()
