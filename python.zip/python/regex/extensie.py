import re

string = re.compile(r'\w+.py+\s')
match = string.findall('ana.pyf \n test.m \n alina.c \n exam.py \n')
print(match)
