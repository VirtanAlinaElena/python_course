import re

site = re.findall('https?://(?:[-\w.]|(?:%[\da-fA-F]{2}))+')
        match = site.findall(website)