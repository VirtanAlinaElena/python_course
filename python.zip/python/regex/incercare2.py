import re
import requests
class TrieNode:
    TrieNodes = 0
    def __init__(self):
        self.children = {}
        self.isURL = False
        self.TrieNodes += 1

    def __del__(self):
        self.TrieNodes -= 1

    def _isLeaf(self):
        return len(self.children) == 0 

    def _isPrefixEnd(self):
        return len(self.children) > 1 or self.isURL

    def __repr__(self):
        return repr(self.children)

    def getFromNode(self):
        if self._isLeaf():
            return ['']

        if self.isURL:
            suffixes = ['']
        else:
            suffixes = []

        for char in self.children:
            suff = self.children[char].getFromNode()
            suff = list(map(lambda s: char + s, suff))
            suffixes += suff

        return suffixes

class Trie:
    def __init__(self):
        self.root = TrieNode()

    def search(self, URL):
        current_node = self.root
        for char in URL:
        	if char in current_node.children.keys():
        		current_node = current_node.children[char]
        	else:
        		return False

        return current_node.isURL

    def insert(self, URL):
        current_node = self.root
        
        for char in URL:
        	if char in current_node.children:
        		current_node = current_node.children[char]
        	else:
        		new_node = TrieNode()
        		current_node.children[char] = new_node
        		current_node = current_node.children[char]

        current_node.isURL = True

    def remove(self, URL):
        current_node = self.root
        prefix_end_node = self.root
        next_char = URL[0]

        for char in URL:
            if char in current_node.children:
                if current_node._isPrefixEnd():
                    prefix_end_node = current_node
                    next_char = char
                current_node = current_node.children[char]
            else:
                return None

        if current_node._isLeaf():
            del prefix_end_node.children[next_char]
        else:
            current_node.isURL = False


    def getWithPrefix(self, prefix):
        current_node = self.root
        for char in prefix:
        	if char in current_node.children.keys():
        		current_node = current_node.children[char]
        	else:
        		return []
        
        suffixes = current_node.getFromNode()
        suffixes = list(map(lambda suffix: prefix + suffix, suffixes))
               
        return suffixes
    

    def __repr__(self):
        return repr(self.root)

#tri = Trie()

class Agenda:
	def __init__(self):
		self.agenda = []
		self.tri = Trie()
	def add(self, nume, email, website, telefon = None):
	

		agenda = []
		persoana = []
		
		persoana.append(nume)

		mail = re.compile(r'\S+@\S+')
		matching = mail.findall(email)
		if matching:
			persoana.append(email)
		else:
			persoana.append('')
			print("Adresa de email gresita")
		site = re.compile('https?://(?:[-\w.]|(?:%[\da-fA-F]{2}))+')
		match = site.findall(website)
		if match:
		#	request = requests.get(website)
		#	if request.status_code == 200:
		#		persoana.append(website)

			else: 
				persoana.append('')
				print("Website invalid")
		else:
			persoana.append('')
			print("Website gresit")


		phoneNumberReg = re.compile(r'\d\d\d\d \d\d\d \d\d\d')
		phonematch = phoneNumberReg.findall(telefon)
		if phonematch:
			persoana.append(telefon)
		else:
			persoana.append('')
			print("Numar de telefon gresit")

		self.agenda.append(persoana)

		tri.insert(nume)
		
	def exists(self, nume):
		if tri.search(nume) == True:
			print (nume + " se gaseste in agenda")
		else:
			print (nume + " nu se gaseste in agenda")


	def get(self, nume):
		for index in self.agenda:
			if nume in index:
				print("NUME:" + index[0])
				if index[3] != '':
					print("TELEFON:" + index[3])
				else:
					print("TELEFON:" + "'N/A'")

				if index[1] != '':
					print("E-MAIL:" + index[1])
				else:
					print("E-MAIL:" + "'N/A'")

				if index[2] != '':
					print("WEBSITE:" + index[2])
				else:
					print("WEBSITE:" + "'N/A'")
			else:
				print ("NUME:" + "'N/A'")


	def delete(self, nume):
		for pers in self.agenda:
			if nume in pers: 
				tri.remove(nume)



# generarea unui nr de telefon random
import random

def phn():
    n = '0000000000'
    while '9' in n[3:6] or n[3:6]=='000' or n[6]==n[7]==n[8]==n[9]:
        n = str(random.randint(10**9, 10**10-1))
    return n[:4] + ' ' + n[3:6] + ' ' + n[7:]

n = phn()
print(n)

# generarea de nume si prenume 
import urllib.request
def name_generator():
  import random
  prenume = ["Jonas","Lora","Michael","Jessica"]
  nume = ["Hammer","Drill","Cutter","Knife"]
  randomNumber1 = random.randrange(0,len(prenume))
  randomNumber2 = random.randrange(0,len(nume))
  name = prenume[randomNumber1] + " " + nume[randomNumber2]
  print(name)

name_generator()

agenda = Agenda()
agenda.add('Dan', 'dan@yahoo.com', 'https://afaf', '0746 234 114')
agenda.exists('Dan')

#dan.get('Dan')