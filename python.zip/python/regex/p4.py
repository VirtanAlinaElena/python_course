import re

vowel = re.compile(r'[aeiouAEIOU]+')
matching = vowel.findall('Alina aioE meie')
print(matching)
print(max(matching, key=len))