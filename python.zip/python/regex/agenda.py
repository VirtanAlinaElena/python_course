class Agenda:
	def __init__(self):
		self.nume = ''
		self.email = ''
		self.website = ''
		self.telefon = ''

	def add(self, nume, email, website, telefon = '0734 246 236'):
		import re

		self.nume = nume;

		mail = re.compile(r'\S+@\S+')
		matching = mail.findall(email)
		if matching:
			self.email = email
		else:
			print("Adresa de email gresita")

		site = re.findall('https?://(?:[-\w.]|(?:%[\da-fA-F]{2}))+')
		match = site.findall(website)
		if match:
			import requests
			request = requests.get(website)
			if request.status_code == 200:
				self.website = website

			else: print("Website invalid")
		else:
			print("Website gresit")


		phoneNumberReg = re.compile(r'\d\d\d\d \d\d\d \d\d\d')
		phonematch = phoneNumberReg.findall(telefon)
		if phonematch:
			self.telefon = telefon
		else:
			print("Numar de telefon gresit")

		
	def exists(self, nume):
		current_node = self.root
		for char in self.nume:
			if char in current_node.children.keys():
				current_node = current_node.children[char]
			else:
				return False


	def get(self, name):
		if self.nume != '':
			print ("NUME: " + self.nume)
		else:
			print ("NUME: " + "'N/A'")

		if self.telefon != '':
			print("TELEFON: " + self.telefon)
		else:
			print ("TELEFON: " + "'N/A'")

		if self.email != '':
			print("E-MAIL: " + self.email)
		else:
			print("E-MAIL: " + "'N/A'")

		if self.website != '':
			print("WEBSITE: " + self.website)
		else:
			print("WEBSITE: " + "'N/A'")


	def delete(self, name):
		



# generarea unui nr de telefon random
import random

def phn():
    n = '0000000000'
    while '9' in n[3:6] or n[3:6]=='000' or n[6]==n[7]==n[8]==n[9]:
        n = str(random.randint(10**9, 10**10-1))
    return n[:4] + ' ' + n[3:6] + ' ' + n[7:]

n = phn()
print(n)

# generarea de nume si prenume 
import urllib.request
def name_generator():
  import random
  prenume = ["Jonas","Lora","Michael","Jessica"]
  nume = ["Hammer","Drill","Cutter","Knife"]
  randomNumber1 = random.randrange(0,len(prenume))
  randomNumber2 = random.randrange(0,len(nume))
  name = prenume[randomNumber1] + " " + nume[randomNumber2]
  print(name)

name_generator()

agenda = Agenda()
agenda.add('Alina', '076 304 1038', 'virtan_alinaa@yahoo.com', 'https://acs.curs.pub.ro')
agenda.get('Alina', '076 304 1038', 'virtan_alinaa@yahoo.com', 'https://acs.curs.pub.ro')