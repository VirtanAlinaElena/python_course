"""
Author: Cebere Tudor
Course: Python Programming @ ccna.ro
"""

class TrieNode:
    TrieNodes = 0
    def __init__(self):
        self.children = {}
        self.isURL = False
        self.TrieNodes += 1

    def __del__(self):
        self.TrieNodes -= 1

    def _isLeaf(self):
        return len(self.children) == 0 

    def _isPrefixEnd(self):
        return len(self.children) > 1 or self.isURL

    def __repr__(self):
        return repr(self.children)

    def getFromNode(self):
        if self._isLeaf():
            return ['']

        if self.isURL:
            suffixes = ['']
        else:
            suffixes = []

        for char in self.children:
            suff = self.children[char].getFromNode()
            suff = list(map(lambda s: char + s, suff))
            suffixes += suff

        return suffixes
            

class Trie:
    def __init__(self):
        self.root = TrieNode()

    def search(self, URL):
        current_node = self.root
        for char in URL:
            if char in current_node.children.keys():
                current_node = current_node.children[char]
            else:
                return False

        return current_node.isURL

    def insert(self, URL):
        current_node = self.root
        
        for char in URL:
            if char in current_node.children:
                current_node = current_node.children[char]
            else:
                new_node = TrieNode()
                current_node.children[char] = new_node
                current_node = current_node.children[char]

        current_node.isURL = True

    def remove(self, URL):
        current_node = self.root
        prefix_end_node = self.root
        next_char = URL[0]

        for char in URL:
            if char in current_node.children:
                if current_node._isPrefixEnd():
                    prefix_end_node = current_node
                    next_char = char
                current_node = current_node.children[char]
            else:
                return None

        if current_node._isLeaf():
            del prefix_end_node.children[next_char]
        else:
            current_node.isURL = False


    def getWithPrefix(self, prefix):
        current_node = self.root
        for char in prefix:
            if char in current_node.children.keys():
                current_node = current_node.children[char]
            else:
                return []
        
        suffixes = current_node.getFromNode()
        suffixes = list(map(lambda suffix: prefix + suffix, suffixes))
               
        return suffixes
    

    def __repr__(self):
        return repr(self.root)