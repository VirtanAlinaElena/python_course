"""
Author: Cebere Tudor
Course: Python Programming @ ccna.ro
"""

class TrieNode:
    TrieNodes = 0
    def __init__(self):
        self.children = {}
        self.isURL = False
        self.TrieNodes += 1

    def __del__(self):
        self.TrieNodes -= 1

    def _isLeaf(self):
        '''
        Metoda care verifica daca un nod anume este frunza in Trie
        Returns:
            True daca nodul e frunza, False altfel.
        '''
        pass

    def _isPrefixEnd(self):
        '''
        Metoda care verifica daca un nod este sfarsitul unui prefix
        comun al mai multor stringuri
        Returns:
            True daca e sfarsitul unui prefix comun, False altfel.
        '''
        return len(self.children) > 1 or self.isURL

    def __repr__(self):
        return repr(self.children)

    def getFromNode(self):
        '''
        Metoda care obtine toate stringurile continute in subarborele din
        Trie care are ca radacina nodul curent
        Returns:
            O lista cu toate stringurile continute in acest subarbore
        '''
        pass 

class Trie:
    def __init__(self):
        self.root = TrieNode()

    def search(self, URL):
        '''
        Metoda care cauta un URL in Trie
        Returns:
            True daca URL-ul se gaseste in Trie, False altfel.
        '''
        pass

    def insert(self, URL):
        '''
        Metoda care insereaza un URL in Trie
        '''
        pass

    def remove(self, URL):
        '''
        Metoda care sterge un URL din Trie
        '''
        pass

    def getWithPrefix(self, prefix):
        '''
        Metoda care gaseste toate URL-urile din Trie care incep cu un
        prefix dat

        Returns:
            Lista cu URL-urile care au prefixul dat
        '''
        pass

    def __repr__(self):
        return repr(self.root)