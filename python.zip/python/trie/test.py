#include <stdio.h>
#include <stdlib.h>

typedef struct queue {
    int data;
    struct queue* next;
}* queue_ptr;

queue_ptr front[10], rear[10]; 

/*
typedef struct queue
{
	int data;
	struct queue* next;
}*front[10], *rear[10];
*/

void add_queue(int i, int data) {
        queue_ptr tmp;

        tmp = (queue_ptr) malloc(sizeof(struct queue));
        tmp->next = NULL;
        tmp->data = data;
        if (front[i]) 
        {
                rear[i]->next = tmp;
                rear[i] = tmp;
        } 
        else 
        {
                front[i] = tmp;
                rear[i] = tmp;
        }
}

int delete_queue(int i) {
        int data;
        queue_ptr tmp;

        tmp = front[i];
        if (!tmp) {
                return -1;  /* So that we can check if queue is empty */
        }
        data = tmp->data;
        front[i] = tmp->next;
        free(tmp);
        return data;
}

void radix_sort(int arr[], int size, int digits) {
        int i, j, k, radix, tmp;

        if (size < 1) 
            return;  

        radix = 1;
        for (i = 0; i < digits; i++) 
        {
                /* distribute to queues */
                for (j = 0; j < size; j++) {
                        add_queue((arr[j] / radix) % 10, arr[j]);
                }
                /* take them out from each queue to the original test array */
 				k = 0; 
                for (j = 0; j < 10; j++)
                {
                	tmp = delete_queue(j);
                	while (tmp != -1)
                	{
                		arr[k] = tmp;
                		k++;
                		tmp = delete_queue(j);
                	}
                }
      
                radix *= 10;
        }
}

int main() {
        int i, digits = 0, x, xdigits;
        int n, a[100];
        scanf("%d", &n);
        for (i = 0; i < n; i++)
        {	scanf("%d", &a[i]);
    		x = a[i];
    		xdigits = 0;
    		while (x) 
    		{
    			x/=10;
    			xdigits++;
    		}
    		if (xdigits > digits) 
    			digits = xdigits;

    	}

        radix_sort(a, n, digits);

        for (i = 0; i < n; i++) {
                printf("%d ", a[i]);
        }
        printf("\n");

        return 0;
}
