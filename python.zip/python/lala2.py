import re

cuvant = re.compile(r'[z]\S+')
match = cuvant.search('Ana are doua zebre virtan_alina@yahoo.com si trei zimbrisori')
print(match.group()) 

# match = cuvant.findall('Ana are doua zebre si trei zimbri')
# print(match)