from StackSolution import Stack

s = Stack()
s.push(2)
s.push(3)
s.print()
print(s.getList())
s.pop()
s.print()
print(s.peek())
s.pop()
s.pop()

print(0x20 * '-')

from Trie import Trie

t = Trie()
t.insert('Andrei')
t.insert('Andra')
print(t.search('Andra'))
