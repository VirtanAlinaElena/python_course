"""
Author: Cebere Tudor
Course: Python Programming @ ccna.ro
"""

class Stack:
	"""
	Clasa ce implementeaza comportamentul unei stive
	
	Atribute:
	stack (list): Lista care va simula comportamentul unei stive.
	"""

	def __init__(self):
		"""
		Definitia constructorului unui stive.
		"""
        pass

	def push(self, element):
		"""
		Metoda care pune un element in varful stivei.
		
		Args:
			element(T): elementul de tip T care va fi pus in varful stivei
		"""
        pass

	def pop(self):
		"""
		Metoda care scoate un element din varful stivei.
		"""
        pass

	def peek(self):
		"""
		Metoda care returneaza elementul din varful stivei fara sa il scoata.
		Returns:
			Elementul din varful stivei daca stiva nu e goala.
			None daca stiva e goala.
		"""
        pass
	def isEmpty(self):
		"""
		Metoda care verifica daca stiva este goala.
		Returns:
			True daca stiva e goala, False altfel.
		"""
        pass

	def print(self):
		"""
		Metoda care printeaza starea curenta a stivei de sus in jos in formatul:
		Top of the Stack
			2
			1
			0
		Bottom of the Stack
		"""
        pass

	def getList(self):
		"""
		Metoda care returneaza starea stivei in ordinea inserarii.
		Returns:
			Lista elementelor in ordinea inserarii.
		"""
        pass

