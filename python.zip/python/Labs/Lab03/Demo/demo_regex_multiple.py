# -*- coding: utf-8 -*-

"""
Author: Danut Matei
Course: Python Programming @ ccna.ro
"""

import re

phoneNumberReg = re.compile(r'\d\d\d\d \d\d\d \d\d\d')


# Daca dorim sa obtinem toate substringurile care fac match cu
# expresia regulata, trebuie sa folosim metoda findall()

matched_strings = phoneNumberReg.findall('Numarul meu de telefon este 0712 345 678, iar numarul lui e 0733 333 333.')

# matched_strings va fi o lista cu toate substringurile gasite

print(matched_strings)
