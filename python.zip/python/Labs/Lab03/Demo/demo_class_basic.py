# -*- coding: utf-8 -*-

"""
Author: Danut Matei
Course: Python Programming @ ccna.ro
"""

class Employee:
    number_of_employees = 0
    employees_list = []

    def __init__(self, name, salary):
        self.name = name
        self.salary = salary
        Employee.employees_list.append(self.name)
        Employee.number_of_employees += 1

    def __del__(self):
        Employee.employees_list.remove(self.name)
        Employee.number_of_employees -= 1


emp1 = Employee("Dan Brown", 10000)
emp2 = Employee("Elon Musk", 1000000)
emp3 = Employee("Jeff Bezos", 999999999)

print(Employee.number_of_employees)
print(Employee.employees_list)

del emp2

print(Employee.number_of_employees)
print(Employee.employees_list)

