# -*- coding: utf-8 -*-

"""
Author: Danut Matei
Course: Python Programming @ ccna.ro
"""

# Pentru a folosi expresii regulate intr-un program Python, trebuie
# sa urmam 4 pasi:

# 1. Importam modulul regex:
import re

# 2. Cream obiectul regex folosim expresia regulata dorita:
phoneNumberReg = re.compile(r'\d\d\d\d \d\d\d \d\d\d')

# 3. Cautam expresia regulata in stringul dorit:
match = phoneNumberReg.search('Numarul meu de telefon este 0712 345 678, dar numarul lui e 0733 333 333.')

# 4. Folosim metoda group() pentru a afla substringul care a facut match
# pe expresia regulata:
print(match.group())
