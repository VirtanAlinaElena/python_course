# -*- coding: utf-8 -*-

"""
Author: Danut Matei
Course: Python Programming @ ccna.ro
"""


class Employee:
    
    def __init__(self, name, salary):
        self.name = name
        self.salary = salary

    def info(self):
        return self.name + " " + str(self.salary)



class Developer(Employee):
    
    def __init__(self, name, salary, known_languages=None):
        super().__init__(name, salary)
        if known_languages is not None:
            self.known_languages = known_languages
        else:
            self.known_languages = []


    def info(self):
        return self.name + " " + str(self.salary) + " " + str(self.known_languages)
        

    def learn_language(self, lang):
        self.known_languages.append(lang)



emp1 = Employee("Mark Zucc", 10000000)
dev1 = Developer("Paul Graham", 200000, ['Lisp', 'Scala', 'Haskell'])
dev2 = Developer("Random Guy 1", 11)
dev3 = Developer("Random Guy 2", 12)

dev2.learn_language('Python')
dev3.learn_language('C++')

print(emp1.info())
print(dev1.info())
print(dev2.info())
print(dev3.info())
