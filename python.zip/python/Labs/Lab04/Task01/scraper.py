import requests 
import re
from bs4 import BeautifulSoup

"""
Exemplu de scraper pentru a gasi toate link-urile intr-un fisier HTML. 

Cautati pe internet in documentatia BeautifulSoup4 cum putem face pentru imagini. :) 
"""

links = ["http://soc.rosedu.org/2018/"]

page = requests.get("http://soc.rosedu.org/2018/")
html_page = page.content

soup = BeautifulSoup(html_page, "html.parser")
links = []

for link in soup.findAll('a', attrs={'href' : re.compile("^http://")}):
	links.append(link.get('href'))

print(links)