# Challenge 1:
	Importati Trie-ul facut data trecuta in sursa scraper.py si inserati link-ul "http://soc.rosedu.org/2018"

# Challenge 2:
	Importati modului request, faceti un GET pe acel site pentru a descarca fisierul HTML folosind beautifulsoup4.

# Challenge 3:
	Rescrieti scraper-ul pentru urmatorul comportament. Plecam de la un URL sursa "soc.rosedu.org/2018".
	Scraper-ul va descarca fisierul HTML-ul al site-ului, va gasi toate link-urile, va baga link-ul
	curent in trie si va continua comportamentul pentru urmatorul link gasit. 

## Exemplu:

	La URL-ul "http://soc.rosedu.org/2018" gasim URL-urile: 'http://rosedu.org', 'http://rosedu.org/',
	'http://creativecommons.org/licenses/by-nc-sa/3.0/', 'http://creativecommons.org/licenses/by-nc-sa/3.0/'.

	Punem 'soc.rosedu.org/2018' in Trie, apoi reluam procesul de mai sus cu URL-ul 'http://rosedu.org'.
	
	Algoritmul va gasi mereu link-uri noi, dorim sa ne oprim dupa un numar predefinit de HTML-uri descarcate.


# Challenge 4:
	Dorim sa modificam Trie-ul pentru a retine de cate ori a fost intalnit un URL. Dorim sa tinem
	si in ce ordine au fost gasite, scrieti in clasa Trie un generator care sa returneze mereu
	numarul link-ului. Daca link-ul este deja in Trie, nu vrem sa primim un numar nou pentru el.


# Challenge 5:
	Descarcati toate imaginile de la acea pagina pentru a le salva in directorul unde se afla sursa py.




