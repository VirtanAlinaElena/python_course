### General

1. Fie doua liste ce contin numere intregi. Creati o a treia lista care sa contina:
a) reuniunea
b) intersectia
c) diferenta

2. Creati o functie care sa calculeze al n-lea termen Fibonacci 

3. Dandu-se doua liste, sortati fiecare lista, dupa care interclasati-le


### Strings

1. Dandu-se un text si o lista de cuvinte, inlocuiti toate aparitiile acestor
cuvinte cu rasturnatele lor.

2. Scrieti o functie care primeste un string s si un numar k si elimina toate
caracterele de pe pozitiile mulipli de k.

3. Scrieti o functie care primeste o lista de cuvinte si un separator si
returneaza un string format din lista de cuvinte concatenate, avand separatorul
intre doua cuvinte consecutive.

### Dictionaries

1. Cititi un text de la tastatura si sortati cuvintele descrescator dupa numarul de
aparitii.

2. Creati o functie care primeste doua dictionare si le unifica intr-un nou
dictionar.

### OS Module

1. Sa se afiseze toate fisierele continute de un path dat.

2. Sa se afiseze, pe rand, directorul curent si continutul acestuia. 
Apoi, sa se creeze un nou fisier ce contine "Py, the best pie, better than pi.".

3. Sa se afiseze un mesaj de forma "Salut! Ma numesc USERNAME si 
m-am logat pe acest calculator ora H si data DD:MONTH.

