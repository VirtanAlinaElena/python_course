# -*- coding: utf-8 -*-

"""
Author: Cebere Tudor
Curs py@ccna
"""

global_var = 10

def func2(argv1):
    #structura if de control
    if global_var == 10:
        print("Global check!")
    else:
        print("Not a global check")
    #variabila global_var este vizibila in toate functiile definite
    #dupa initializarea ei, folosirea lor de cele mai multe ori este
    #un bad practice
    
    #variabile locala are scope-ul doar in func2, dupa ce a fost definita
    local_var = 10
    if local_var == 10 :
        print("Local check!")
    else:
        print("Not a local check!")
    
    if argv1 == 10 :
        print("Argv check!\n")
    else:
        print("Not argv check!\n") 
    #daca nu folosim return intr-o functie, automat va intoarce None
    
#putem folosi structuri de control si inafara functiilor, zona globala
#dintr-un script python fiid interpretata si ea

print("Primul apel:")
func2(10)

global_var += 1

print("Al doilea apel:")
returned_value = func2(11)

if returned_value == None:
    print("func2 a returnat None!\n")   
