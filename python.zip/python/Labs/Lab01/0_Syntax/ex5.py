"""
Author: Dorin Geman
Curs py@ccna
"""

import operator

bools = []
false = ('nu', 0) # Tuple, sau Pair din C++
true = ('da', 1)

bools.append(false)
bools.append(true)
print(bools)

sorted_by_strings = sorted(bools, key = operator.itemgetter(0))
print(sorted_by_strings)


