"""
Author: Dorin Geman
Curs py@ccna
"""

# range(x, y) simuleaza pasii de la x la y-1
numberList = list(range(0, 10))
print(numberList)

# insert(i, x) insereaza valoarea x la pozitia p
numberList.insert(2, 10)
numberList.insert(2, -100)
print(numberList)

# remove(x) elimina din lista toate elementele egale cu x
numberList.remove(10)
print(numberList)

# append(x) adauga x la finalul listei
numberList.append(-11)
print(numberList)

# sort() sorteaza lista
numberList.sort()
print(numberList)

# pop() elimina ultimul element din lista
numberList.pop()
print(numberList)

# reverse() inverseaza ordinea elementelor din lista
numberList.reverse()
print(numberList)
