# -*- coding: utf-8 -*-

"""
Author: Cebere Tudor
Curs py@ccna
"""
#exemplu de lista in python
x = [2, 3, 4]
#De ce merg urmatoarele doua instructiuni
print("List of integers:")
print(x)
#dar linia urmatoare nu?
#print("List of integers" + x)
#operatorul + incearca sa concateneze doua string-uri, dar gaseste un
#string si o lista. Hint: str()

#listele in python pot contine orice
y = ["Dorinel", "e", "frumi"]

#Parcurgerea unei liste pe baza iteratorilor
for token in y:
    print(token)

#Parcurgerea unei liste pe baza indexului
for i in range(0, len(y)):
    print(y[i])
    
#explicatie:
#i - indexul curent
#len(y) - lungimea listei
#range(0, len(y)) creeaza - creeaza o lista care sa contina [0, 1, .. len(y)]
# ia cate un element din lista in ordine si il foloseste ca index
