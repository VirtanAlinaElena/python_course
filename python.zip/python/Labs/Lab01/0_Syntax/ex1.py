# -*- coding: utf-8 -*-

"""
Author: Cebere Tudor
Curs py@ccna
"""

# scrierea unei functii elementare in python
def func():
    #la fiecare imbricare, trebuie tab
    return "Basic function"
    #cand vrem sa trecem la un nivel imbricare inferior, folosim un tab in minus

#apelam functia scrisa mai sus
returned_value = func()
print(returned_value)
print(func())
