# -*- coding: utf-8 -*-

"""
Author: Matei Danut
Curs py@ccna
"""

# In general, un dictionar este o multime de asocieri de tipul: cheie -> valoare

# Conceptual, acestea pot fi privite ca o extindere a listelor
culori = ["rosu", "albastru", "galben", "verde"]

# In timp ce elementele unei liste pot fi indexate prin pozitia lor
print(culori[1])
print(culori[2])

# Elementele unui dictionar pot fi indexate prin intermediul cheilor, care 
# pot fi:

# - intregi
numere = {2: "doi", 9: "noua", 13: "treisprezece"}
print(numere[2])

# - siruri de caractere
populatie = {"Romania": 19640000, "Anglia": 54790000}
print(populatie["Romania"])

# - tupluri
anagrame = {("ana", "naa"): True, ("abc", "abb"): False}
print(anagrame[("abc", "abb")])

# In general, cheile trebuie sa fie tipuri imutabile, deci spre exemplu nu vom
# putea avea liste drept chei

# Nu exista o restrictie asupra tipurilor pe care le pot avea valorile
