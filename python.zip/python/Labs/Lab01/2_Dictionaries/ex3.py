# -*- coding: utf-8 -*-

"""
Author: Matei Danut
Curs py@ccna
"""

culori = {}
culori["negru"] = 0x000000
culori["rosu"]  = 0xFF0000
culori["alb"]   = 0xFFFFFF

# Pentru a obtine lista tuturor cheilor din dictionar:
# - in ordinea insertiei:
print(list(culori))

# - in ordine alfabetica:
print(sorted(culori))


# Putem testa apartenta unei chei la un dictionar in felul urmator:
print("negru" in culori)
print("verde" in culori)
print("albastru" not in culori)
print()


# Putem scoate o cheie din dictionar:
print("alb" in culori)

del culori["alb"]

print("after delete:")
print("alb" in culori)

