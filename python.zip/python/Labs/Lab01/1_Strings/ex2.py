# -*- coding: utf-8 -*-

"""
Author: Matei Danut
Curs py@ccna
"""

# Stringurile sunt similare cu listele.
# Pot fi indexate la fel:
s = "abcd"
print(s[1])

# Putem selecta un substring la fel cum selectam o parte a unei subliste:
s = "banana"
ss = s[2:]
print(ss)

# Pentru a selecta ultime 3 caractere procedam in felul urmator:
w = s[-3:]
print(w)

# Pentru a selecta un interval:
c = s[2:4]
print(c)
