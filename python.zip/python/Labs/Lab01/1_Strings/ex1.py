# -*- coding: utf-8 -*-

"""
Author: Matei Danut
Curs py@ccna
"""

# In python, stringurile sunt secvente de caractere incadrate intre "" sau ''
nume = "Popescu"
prenume = 'George'

# Structural, nu exista nicio diferenta intre cele doua reprezentari
print(nume)
print(prenume)

# Motivul pentru care am vrea uneori sa folosim una dintre ele este pentru a nu
# avea nevoie sa escapam caracterele speciale ' si "
s = 'Primul cuvant din alfabet este "aalenian"'
print(s)

w = "Sal'tare!"
print(s)

# Daca trebuie sa folosim ambele caractere in propozitie, va trebui sa escapam
# unul dintre ele
s = "Primu' cuvant din alfabet este \"aalenian\""
print(s)

# De asemenea, cum ati vazut si in headerul fiecarui exercitiu de pana acum,
# putem defini un string care contine caractere \n in acelasi mod in care
# cream comentarii pe mai multe randuri
print("""Author: Matei Danut
        Curs py@ccna
        Laboratorul 1""")
