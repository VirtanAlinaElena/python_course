# -*- coding: utf-8 -*-

"""
Author: Matei Danut
Curs py@ccna
"""

# Uneori, avem nevoie sa manipulam caile fisierelor si directoarelor.
# Pentru acest lucru, folosim functiile din os.path

import os.path as path

# Pentru a obtine adresa absoluta, cunoscand adresa relativa folosim
# functia abspath()
relative_path = "director"
print("Adresa absoluta a fisierului " + relative_path + " este:")
absolute_path = path.abspath(relative_path)
print(absolute_path)

# Pentru a realiza operatia inversa folosim basename()
print(path.basename(absolute_path))
print()

# Pentru a crea un path din numele unor directoare, putem folosi
# functia join()
print(path.join("facultate", "teme", "tema1", "bin"))
print()
# Avantajul aceste aboradi fata de o constructie de genul:
# print("facultate" + "/" + "teme" + "/" + "tema1" + "/" + "bin")
# este faptul ca join() creaza path-ul in functie de sistemul de operare
# Astfel, pe windows am obtine "facultate\teme\tema1\bin"

# O alta functie utila este exists()
print(path.exists("director"))
print(path.exists("file.txt"))
print()

# Putem verifica daca un path se refera la un fisier sau la un director astfel:
print(path.isfile("director"))
print(path.isdir("director")) 
print()

# Pentru a explicita caracterul ~ in directorul home al utilizatorului curent, 
# folosim functia expanduser()
print(path.expanduser("~/Desktop/homework"))
