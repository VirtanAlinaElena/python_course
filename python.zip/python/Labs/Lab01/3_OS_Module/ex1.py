# -*- coding: utf-8 -*-

"""
Author: Matei Danut
Curs py@ccna
"""

# Pentru a putea folosi functionalitati similare cu cele ale comenzilor din bash,
# putem folosi functiile importate din modulul os:

import os

# Se poate astfel sa folosim functii echivalente cu cele din bash:
# - pwd
print("Adresa absoluta a directorului curent este:\n" + os.getcwd())

print()

# - ls
print("Fisierele si directoarele din directorul curent sunt: ")
for x in os.listdir():
    print(x)

# - mkdir
# de tinut minte ca crearea unui director va genera o exceptie daca acel
# director deja exista
os.mkdir("director1")
os.mkdir("director2")

# Daca dorim sa cream recursiv o ierarhie de fisiere, varianta de mai jos nu va functiona:
# os.mkdir("facultate/teme/tema1")
# Va trebui sa folosim in schimb functia makedirs():
os.makedirs("facultate/teme/tema1")
os.makedirs("jocuri/warcraft3/")

# - rmdir
# de tinut minte ca stergerea unui director care nu exista va genera o exceptie
os.rmdir("director1")
os.rmdir("director2")
# Functia echivalenta pentru stergerea recursiva a unei ierarhii de fisiere este removedirs()
os.removedirs("facultate/teme/tema1")
os.removedirs("jocuri/warcraft3/")

# - touch
os.mknod("useless_file.txt")
os.mknod("script.sh")

# - chmod
os.chmod("script.sh", 0o777)
# prefixul 0o indica faptul ca numarul este in baza 8
# in bash, numarul primit ca argument de comanda bash, care specifica
# permisiunile, era tot in baza 8, insa nu trebuia sa mentionam acest lucru 
# in mod explicit

# - rm 
os.remove("useless_file.txt")
os.remove("script.sh")

# In plus, mai dispunem de functia rename():
os.mknod("file.txt")
os.rename("file.txt", "file1.txt")
os.remove("file1.txt")
