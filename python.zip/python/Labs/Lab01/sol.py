# Fie doua liste ce contin numere intregi. Creati o a treia lista care sa contina:

# a) reuniunea

def reunion_v1(a, b):
    res = a.copy()
    for elem in b:
        if elem not in res:
            res.append(elem)
    return res

list_a = [1, 2, 3, 4, 5]
list_b = [2, 3, 4, 5, 6]
#print(reunion(list_a, list_b))

# b) intersectia

def intersection_v1(a, b):
    res = []
    for elem in a:
        if elem in b:
            #b.remove(elem)
            res.append(elem)
    return res

def intersection_v2(a, b):
    res = []
    for elem_a in a:
        for elem_b in b:
            if elem_a == elem_b:
                #b.remove(elem)
                res.append(elem_a)
    return res

#print(intersection_v1(list_a, list_b))


# c) diferenta

def diff(a, b):
    res = []
    for elem in a:
        if elem not in b:
            res.append(elem)
    return res

#print(diff(list_a, list_b))

# Creati o functie care sa calculeze al n-lea termen fibonnaci.

def fibo(nth, first, second):
    if nth == 0:
        return first

    first, second = first + second, first
    return fibo(nth - 1, first, second)


#Dandu-se doua liste, sortati fiecare lista, dupa care interclasati-le

list_a = [5, 1, 13, 8, 23, 25]
list_b = [7, 3, 2, 20]

def intercls_v1(list_a, list_b):
    res = []
    idx_a = 0
    idx_b = 0
    list_a.sort()
    list_b.sort()
    while idx_a < len(list_a) and idx_b < len(list_b):
        if list_a[idx_a] < list_b[idx_b]:
            res.append(list_a[idx_a])
            idx_a += 1
        else:
            res.append(list_b[idx_b])
            idx_b += 1

        if idx_a == len(list_a):
            res.extend(list_b[idx_b:])
            break

        if idx_b == len(list_b):
            res.extend(list_a[idx_a:])
            break

    return res

print(intercls_v1(list_a, list_b))

#2.1
text = "Super Super wow wow mi-a placut la munte am mancat snitele"
cuvinte = ["Super", "munte", "snitel"]

def replace_in_text(text, cuvinte):
    tokens = text.split()
    res = []
    print(tokens)
    for item in tokens:
        if item in cuvinte:
            res.append(item[::-1])
        else:
            res.append(item)
    res = " ".join(res)
    return res

print(replace_in_text(text, cuvinte))



#2.2

text = "0123456789"
k = 3

def remove_kth(text, k):
    for i in range(0, len(text)):
        if i % k == 0:
            text = text[:i] + '_' + text[i + 1:]
    text = text.replace('_', '')
    return text

#2.3
list_of_words = ["ana", "are", "mere"]
sep = ","
def unify(list_of_words, sep):
    res = ""
    for item in list_of_words:
        res = res + item + sep
    return res[:-1]
print(unify(list_of_words, sep))
print(sep.join(list_of_words)) # Acelasi lucru, mult mai scurt
