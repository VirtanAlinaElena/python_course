# -*- coding: utf-8 -*-

"""
Author: Dorin Geman
Course: Python Programming @ ccna.ro
"""

a = (1, 2, 'Tudy') # tuple
b = [1, 2, 'Tudy'] # list

# tuples are immutable
#a[0] = 3
b[0] = 3


