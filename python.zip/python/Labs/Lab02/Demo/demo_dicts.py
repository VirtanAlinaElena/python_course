# -*- coding: utf-8 -*-

"""
Author: Dorin Geman
Course: Python Programming @ ccna.ro
"""

song = {
	'title': 'here we go',
	'artist': 'damian jr gong marley',
	'release date': 2017 # int
}

# print(song)

# print(song['title'])
# print(song.get('title'))

# We can change the value of a key
song['release date'] = 'summer of 2017' # string

for i in song.keys():
	print(i)

for i in song.values():
	print(i)

for i in song.items():
	print(i)

song['rating'] = 10
print(song)

# We can check if a key exists
if 'rating' in song:
	print(True)
# We can't check if a value exists
if 'damian jr gong marley' in song:
	print(True)

song.pop('rating')
print(song)




