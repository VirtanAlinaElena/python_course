# -*- coding: utf-8 -*-

"""
Author: Dorin Geman
Course: Python Programming @ ccna.ro
"""

import myfirstmodule as my1mod

a = -10
my1mod.add(a, 100)
my1mod.add(my1mod.a, 100)
