# -*- coding: utf-8 -*-

"""
Author: Dorin Geman
Course: Python Programming @ ccna.ro
"""

info = "Aloha"
a = 31

def add(x, y):
	print(x + y)