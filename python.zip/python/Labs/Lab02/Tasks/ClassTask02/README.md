# Challenge:
	Task-ul urmareste implementarea functionalitatii unui blender. In cadrul 
	clasei, vrem sa luam in constructor consumabilele si retelele pe care le poate face.
	Trebuie sa implementati functiile:
	- asteapta_comanda: primeste o comanda.
	- lista de comenzi:
		- list: afiseaza retele disponibile
		- status: afiseaza consumabilele
		- make: face shake-ul cerut daca are resursele, daca nu, afiseaza o eroare.