# Challenge 1:
	Desenati pe foaie legaturile dintre clasele descrise in fisierul sursa.

# Challenge 2:
	Implementati o noua clasa care sa derive Arachnidele: Tarantula. Nu trebuie sa aiba acces la metoda kiss_mary_jane.

# Challenge 3:
	BabyTiger-ul trebuie sa stie sa se apere de toti monstrii inainte sa creasca, implementati metoda defend() versus toti atacatorii

# Challenge 4:
	BabyTiger-ul are foarte mult timp sa isi analizeze potentialii adversari, dar cand se intalneste cu unul complet nou nu stie ce sa faca. Tiger-ul are mai multa experienta si in functia be_awesome va trata doar tipurile: Om, Tigru, Arachnida si toate derivarile sale! Hint: issubclass. Pentru ce nu e din aceste clase + derivari, va avea un comportament diferit

