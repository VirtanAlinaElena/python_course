# -*- coding: utf-8 -*-

"""
Author: Dorin Geman
Course: Python Programming @ ccna.ro
"""

# The values are on the same line
a, b = map(int, input().split())

print(a + b)
