#!/bin/bash

sudo apt-get install python3-venv 

python3 -m venv ~/Python

cp python3.sublime-build ~/.config/sublime-text-2/Packages/User

