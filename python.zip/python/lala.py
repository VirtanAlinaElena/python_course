if __name__ == '__main__':
    import operator
    stud=[ ["Harry", 37.21], ["Berry", 37.21], ["Tina", 37.2], ["Akri", 41] ]
    sortclass = sorted(stud, key = operator.itemgetter(1))
    list = []
    i = 1
    while sortclass[0][1] == sortclass[i][1]:
        i = i + 1
    list.append(sortclass[i])
    j = i + 1
    while sortclass[i][1] == sortclass[j][1]:
            list.append(sortclass[j])
            j = j + 1
    list.sort()
    print(list)
    for i in list:
    	print(i[0])