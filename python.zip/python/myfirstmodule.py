import re

string = 'alina.py\nana.py\ntest.m'
print(string)
vowel = re.compile(r'[aeiouAEIOU]+')
matching = vowel.findall('Alina aioE meie')
print(matching)
print(max(matching, key=len))