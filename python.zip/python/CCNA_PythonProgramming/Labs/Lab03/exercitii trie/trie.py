"""
Author: Cebere Tudor
Course: Python Programming @ ccna.ro
"""

class TrieNode:
    TrieNodes = 0
    def __init__(self):
        self.children = {}
        self.isURL = False
        self.TrieNodes += 1

    def __del__(self):
        self.TrieNodes -= 1

    def _isLeaf(self):   
        if len(self.children) == 0:
            return True
        else:
            return False

    def _isPrefixEnd(self):
        return len(self.children) > 1 or self.isURL

    def __repr__(self):
        return repr(self.children)

    def getFromNode(self):
        '''
        Metoda care obtine toate stringurile continute in subarborele din
        Trie care are ca radacina nodul curent
        Returns:
            O lista cu toate stringurile continute in acest subarbore
        '''

class Trie:
    def __init__(self):
        self.root = TrieNode()

    def search(self, URL):
        node = self.root
        for char in URL:
            char_not_found = True
            for child in node.children.keys():
                if child.char == char:
                    char_not_found = False
                    node = child 
                    break
            if char_not_found:
                return False

        return True


    def insert(self, URL):
        node = self.root
        for char in URL:
            found_in_child = False
            for child in node.children:
                if child.char == char:
                    child.TrieNodes += 1
                    node = children
                    found_in_children = True
                    break
            if not found_in_char:
                new_node = TrieNode()
                node.children[char] = new_node
                node = new_node
        node.isURL = True
        
    current_node = self.root

    for char in URL:
        if char in node.children:
            node = node.children[char]
        else:
            new_node = TrieNode()
            node.children[char] = new_node
            node = node.children[char]
            ...
    def remove(self, URL):
        '''
        Metoda care sterge un URL din Trie
        '''
        pass

    def getWithPrefix(self, prefix):
        '''
        Metoda care gaseste toate URL-urile din Trie care incep cu un
        prefix dat

        Returns:
            Lista cu URL-urile care au prefixul dat
        '''
        pass


    def __repr__(self):
        return repr(self.root)