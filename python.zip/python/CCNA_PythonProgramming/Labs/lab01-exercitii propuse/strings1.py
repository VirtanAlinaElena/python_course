list = ["Ana", "mere", "portocale", "galben"]
s = "Ana are mere galbene si portocale mari"
for i in list:
	s = s.replace(i, i[::-1])
print (s)