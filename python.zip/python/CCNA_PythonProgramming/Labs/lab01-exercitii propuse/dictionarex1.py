str = 'ana are mere ana ana'

list = str.split(' ')

print(list)

dict1 = {}
for i in list:
	dict1[i] = 0
for i in list:
	dict1[i] += 1

print(dict1)

