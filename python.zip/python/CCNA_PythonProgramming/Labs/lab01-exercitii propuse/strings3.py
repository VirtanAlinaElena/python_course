list = ["ana", "are", "mere", "rosii"]
sep = " "
s = ""
for i in list:
	s += i + sep
print(s)