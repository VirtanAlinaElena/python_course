# -*- coding: utf-8 -*-

"""
Author: Cebere Tudor
Course: Python Programming @ ccna.ro
"""

class Fruct:
	def __init__(self, cantitate):
		self.cantitate = cantitate
		print(self.cantitate)

	def shake(self):
		pass

class Mar(Fruct):
	def __init__(self, cantitate):
		super().__init__(cantitate)
		
	def shake(self):
		print("Marul este in blender.")

class Portocala(Fruct):
	def __init__(self, cantitate):
		super().__init__(cantitate)

	def shake(self):
		print("Portocala este in blender.")

class Ananas(Fruct):
	def __init__(self, cantitate):
		super().__init__(cantitate)

	def shake(self):
		print("Ananas-ul este in blender.")

class Blender:
	def __init__(self, consumabile, recipes):
		self.consumabile = consumabile
		self.recipes = recipes

	def asteapta_comanda(self, comanda):
		if (comanda == 0):
			print("Nu s-a primit nicio comanda")
		if (comanda == 1):
			print("Prepara shake-ul cu mar si portocala")
		if (comanda == 2):
			print("Prepara shake-ul cu mar si ananas")
		if (comanda == 3):
			print("Prepara shake-ul multifruct: mar, portocala, ananas")


	def list(self):
		print("Reteta1: shake cu mar si portocala")
		print("Reteta2: shake cu mar si ananas")
		print("Reteta3: shake multifruct: mar, portocala, ananas")
		

	def status(self):
		printf("Consumabile: mar, portocala, ananas")

	def make(self, reteta_de_facut):
			if self.consumabile == 3: 
				if reteta_de_facut == 1:
					print("Prepara shake-ul cu mar si portocala")
				elif reteta_de_facut == 2:
					print("Prepara shake-ul cu mar si ananas")
				elif reteta_de_facut == 3:
					print("Prepara shake-ul cu mar, portocala si ananas")
			else:
				print("Shake-ul nu a putut fi preparat")
mar = Mar(5)
mar.shake()
portocala = Portocala(7)
portocala.shake()
ananas = Ananas(4)
ananas.shake()

a = Blender(3, 3)
a.asteapta_comanda(2)
a.make(1)
